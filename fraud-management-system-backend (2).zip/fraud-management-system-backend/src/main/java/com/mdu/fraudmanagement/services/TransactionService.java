package com.mdu.fraudmanagement.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mdu.fraudmanagement.entities.Transaction;
import com.mdu.fraudmanagement.repos.TransactionRepository;

@Service
public class TransactionService {
	@Autowired
	TransactionRepository transactionRepository;

	public void registerOrUpdateTransaction(Transaction transaction) {

		transactionRepository.save(transaction);

	}
	public void deleteTransaction(Transaction transaction) {

		transactionRepository.delete(transaction);

	}
	
	
}