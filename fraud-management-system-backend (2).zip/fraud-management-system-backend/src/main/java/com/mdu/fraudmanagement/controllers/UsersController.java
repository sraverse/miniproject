package com.mdu.fraudmanagement.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mdu.fraudmanagement.entities.Users;
import com.mdu.fraudmanagement.services.UserService;

@RestController
public class UsersController {
	
	@Autowired
	UserService userService;
	
	@PostMapping("/registration")
	private int registerUser(@RequestBody Users users) {
		
		userService.registerOrUpdateUser(users);
		
		return users.getId();
	}

}
