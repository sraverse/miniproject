package com.mdu.fraudmanagement.repos;

import java.util.List;

import com.mdu.fraudmanagement.entities.Card;


public interface CardServiceDao {
	
	List<Card> getAllCard();
	Card findCard(int Id);

}
