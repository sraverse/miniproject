package com.mdu.fraudmanagement.entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.*;

@Entity
@Table(name="USERS")
public class Users implements Serializable {
	
	
	
	@Id
	@Column(name="userId")
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;
	
	
	private String firstName;
	private String lastName;
	private Date dob;
	private String gender;
	private String contactNo;
	private String email;
	private String password;
	private boolean isAdmin;
	private boolean isAuthorized;
	
	
	
	
	
	
	
	
	public Users(int id, String firstName, String lastName, Date dob, String gender, String contactNo, String email,
			String password, boolean isAdmin, boolean isAuthorized) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dob = dob;
		this.gender = gender;
		this.contactNo = contactNo;
		this.email = email;
		this.password = password;
		this.isAdmin = isAdmin;
		this.isAuthorized = isAuthorized;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public boolean isAdmin() {
		return isAdmin;
	}
	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}
	public boolean isAuthorized() {
		return isAuthorized;
	}
	public void setAuthorized(boolean isAuthorized) {
		this.isAuthorized = isAuthorized;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", dob=" + dob + ", gender="
				+ gender + ", contactNo=" + contactNo + ", email=" + email + ", password=" + password + ", isAdmin="
				+ isAdmin + ", isAuthorized=" + isAuthorized + "]";
	}
	
	
	
	
	
	

}

/*
 * why JPA entities should implement the Serializable interface?
 * https://stackoverflow.com/questions/2020904/when-and-why-jpa-entities-should-implement-the-serializable-interface#:~:text=If%20we%20are%20exposing%20domain,can%20be%20serialized%20or%20clustered.
*/	