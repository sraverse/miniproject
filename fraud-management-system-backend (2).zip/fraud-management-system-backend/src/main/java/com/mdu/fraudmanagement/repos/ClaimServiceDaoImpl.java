package com.mdu.fraudmanagement.repos;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.mdu.fraudmanagement.entities.Claim;


@Configuration
public class ClaimServiceDaoImpl implements ClaimServiceDao {
	
	@Autowired(required = true)
	private ClaimRepository claimRepository;

	@Override
	public List<Claim> getAllClaim() {
		return claimRepository.findAll();
	}

	@Override
	public Claim findClaim(int id) {

		Optional<Claim> cl = claimRepository.findById(id);
		if(cl.isPresent())
		{
			return cl.get();
		}
		
		
		return null;
	}

}
