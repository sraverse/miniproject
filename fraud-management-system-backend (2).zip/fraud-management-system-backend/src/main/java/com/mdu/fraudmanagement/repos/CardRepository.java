package com.mdu.fraudmanagement.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mdu.fraudmanagement.entities.Card;

public interface CardRepository extends JpaRepository<Card, Integer> {

}
