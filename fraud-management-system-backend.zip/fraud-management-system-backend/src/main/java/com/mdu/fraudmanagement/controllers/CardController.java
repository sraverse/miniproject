package com.mdu.fraudmanagement.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mdu.fraudmanagement.entities.Card;
import com.mdu.fraudmanagement.entities.Claim;
import com.mdu.fraudmanagement.services.CardService;

@RestController
public class CardController {
	
	
	
	@Autowired
	CardService cardService;
	
	@PostMapping("/user/card")
	private int registerCard(@RequestBody Card card) {
		
		cardService.registerOrUpdateCard(card);
		
		return card.getId();

}
	@PostMapping("/user/frauds/card/delete") 
	private int addCard(@RequestBody Card card) {
	return card.getId();}
	
}
