package com.mdu.fraudmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FraudmanagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
