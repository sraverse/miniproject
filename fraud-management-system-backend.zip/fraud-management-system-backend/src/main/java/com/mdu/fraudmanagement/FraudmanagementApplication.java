package com.mdu.fraudmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FraudmanagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(FraudmanagementApplication.class, args);
    }

}
