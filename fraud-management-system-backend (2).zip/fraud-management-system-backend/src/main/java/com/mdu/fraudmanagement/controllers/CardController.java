package com.mdu.fraudmanagement.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mdu.fraudmanagement.entities.Card;
import com.mdu.fraudmanagement.repos.CardServiceDaoImpl;
import com.mdu.fraudmanagement.services.CardService;

@RestController
public class CardController {
	
	
	
	@Autowired
	CardService cardService;
	
	
	@Autowired
	private CardServiceDaoImpl cardServiceDaoimpl;
	
	@PostMapping("/user/card")
	private int registerCard(@RequestBody Card card) {
		
		cardService.registerOrUpdateCard(card);
		
		return card.getId();

}
	@DeleteMapping("/user/frauds/card/delete") 
	private int deleteCard(@RequestBody Card card) {
		cardService.deleteCard(card);
	return card.getId();
	}

	@GetMapping("/card")
	List<Card> getAllCard() {
		return cardServiceDaoimpl.getAllCard();
	}
	@GetMapping("/card/{id}")
	ResponseEntity<Card> getById(@PathVariable int id){
		Card cd = cardServiceDaoimpl.findCard(id);
		
		return new ResponseEntity<Card>(cd,HttpStatus.OK);
	}

	
}
