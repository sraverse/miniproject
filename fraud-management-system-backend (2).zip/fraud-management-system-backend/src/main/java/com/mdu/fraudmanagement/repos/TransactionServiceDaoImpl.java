package com.mdu.fraudmanagement.repos;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.mdu.fraudmanagement.entities.Transaction;


@Configuration
public class TransactionServiceDaoImpl implements TransactionServiceDao {
	
	@Autowired(required = true)
	private TransactionRepository transactionRepository;

	@Override
	public List<Transaction> getAllTransactions() {
	
		return transactionRepository.findAll();
	}

	
	@Override
	public Transaction findTransaction(int id) {
		
		
		Optional<Transaction> tr = transactionRepository.findById(id);
		if(tr.isPresent())
		{
			return tr.get();
		}
		
		return null;
	}

}
