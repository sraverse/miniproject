package com.mdu.fraudmanagement.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mdu.fraudmanagement.entities.Users;
import com.mdu.fraudmanagement.repos.UserRepository;

@Service
public class UserService {
	
	@Autowired
	UserRepository userRepository;
	
	
	//new registration of user
	public void registerOrUpdateUser(Users users) {
		
		userRepository.save(users);
		
	}
}
