package com.mdu.fraudmanagement.repos;

import java.util.List;

import com.mdu.fraudmanagement.entities.Claim;

public interface ClaimServiceDao {
	
	List<Claim> getAllClaim();
	Claim findClaim(int Id);

}
