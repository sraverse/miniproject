package com.mdu.fraudmanagement.repos;

import java.util.List;

import com.mdu.fraudmanagement.entities.Transaction;

public interface TransactionServiceDao {
	List<Transaction> getAllTransactions();
	Transaction findTransaction(int Id);

}
