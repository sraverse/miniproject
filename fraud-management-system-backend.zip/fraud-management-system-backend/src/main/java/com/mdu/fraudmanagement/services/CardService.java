package com.mdu.fraudmanagement.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mdu.fraudmanagement.entities.Card;
import com.mdu.fraudmanagement.entities.Claim;
import com.mdu.fraudmanagement.entities.Users;
import com.mdu.fraudmanagement.repos.CardRepository;

@Service
public class CardService {
	
	
	@Autowired
	CardRepository cardRepository;
	
	
	//new registration of user
	public void registerOrUpdateCard(Card card) {
		
	cardRepository.save(card);
		
	}
	public void addCard(Card card) {
		
		cardRepository.delete(card);
		}

}
