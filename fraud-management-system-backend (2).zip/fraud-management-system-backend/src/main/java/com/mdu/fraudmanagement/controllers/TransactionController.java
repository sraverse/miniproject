package com.mdu.fraudmanagement.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.mdu.fraudmanagement.entities.Transaction;
import com.mdu.fraudmanagement.repos.TransactionServiceDaoImpl;
import com.mdu.fraudmanagement.services.TransactionService;

@RestController
public class TransactionController {
	@Autowired
	TransactionService transactionService;
	@Autowired
	TransactionServiceDaoImpl transactionServiceDaoimpl;

	

	@PostMapping("/transaction")
	private int registerTransaction(@RequestBody Transaction transaction) {

		transactionService.registerOrUpdateTransaction(transaction);

		return transaction.getId();

	}

	@DeleteMapping("/transaction/delete")
	private int deleteTransaction(@RequestBody Transaction transaction) {

		transactionService.deleteTransaction(transaction);

		return transaction.getId();

	}
	@GetMapping("/transactions")
	List<Transaction> getAllTransactions() {
		return transactionServiceDaoimpl.getAllTransactions();
	}
	@GetMapping("/transaction/{id}")
	ResponseEntity<Transaction> getById(@PathVariable int id){
		Transaction tran = transactionServiceDaoimpl.findTransaction(id);
		
		return new ResponseEntity<Transaction>(tran,HttpStatus.OK);
	}

	
}
