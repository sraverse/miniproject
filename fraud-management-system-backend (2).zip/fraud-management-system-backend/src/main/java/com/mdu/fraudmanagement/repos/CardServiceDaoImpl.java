package com.mdu.fraudmanagement.repos;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.mdu.fraudmanagement.entities.Card;

@Configuration
public class CardServiceDaoImpl implements CardServiceDao {

	@Autowired(required = true)
	private CardRepository cardRepository;
	
	@Override
	public List<Card> getAllCard() {
		return cardRepository.findAll();
	}

	@Override
	public Card findCard(int id) {
		
		Optional<Card> cr = cardRepository.findById(id);
		if(cr.isPresent())
		{
			return cr.get();
		}
		
		
		return null;
	}

}
