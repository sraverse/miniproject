package com.mdu.fraudmanagement.entities;

public class Transaction {

}
