package com.mdu.fraudmanagement.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mdu.fraudmanagement.entities.Users;

public interface UserRepository extends JpaRepository<Users, Integer> {

}
